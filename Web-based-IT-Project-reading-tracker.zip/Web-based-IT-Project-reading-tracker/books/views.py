from django.shortcuts import render


from rest_framework.viewsets import ModelViewSet
from .models import Book
from .serializers import BookSerializer

class BookViewSet(ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer


import requests
from rest_framework.views import APIView
from rest_framework.response import Response

class GoogleBooksSearch(APIView):
    def get(self, request):
        query = request.GET.get('q')
        api_key = 'YOUR_GOOGLE_BOOKS_API_KEY'
        url = f'https://www.googleapis.com/books/v1/volumes?q={query}&key={api_key}'
        response = requests.get(url)
        return Response(response.json())
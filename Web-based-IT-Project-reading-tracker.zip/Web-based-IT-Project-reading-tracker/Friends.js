import './App.css';
import React from 'react';


function Friends() {
    return (
  
    <div>
    <h2>Welcome to the Friend Page</h2>
    <p>Here you can view all your friends.</p>
  </div>
);
}


export default Friends;
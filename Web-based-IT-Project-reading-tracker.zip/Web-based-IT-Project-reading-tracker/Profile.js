import './Profile.css';
import React from 'react';


function Profile() {
    return (
  
    <div className='Profile-container'>
        <h1>All about you!  </h1>
        <p>Fill this shit out</p>
    </div>
);
}




export default Profile
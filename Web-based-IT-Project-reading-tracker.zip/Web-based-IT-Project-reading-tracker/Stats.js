import './Stats.css';
import React from 'react';


function Stats() {
    return (
  
        <div className='stat-container'>
        <h1>Statistics </h1>
        <p>This is where you can view all of the info about your reading</p>
      </div>
);
}


export default Stats;